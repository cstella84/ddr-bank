# @hashicorp/vault-runtime-credential-sdk

Vault credential provider chain SDK with multi-engine secret retrieval for server-side JavaScript runtimes.

## Overview

A TypeScript SDK that resolves HashiCorp Vault credentials through a configurable provider chain, then reads secrets from multiple Vault engines. Built for **server-side workloads** — this SDK is not intended for client-side or browser-based applications.

- **Server-side runtimes** — works in Node.js, Bun, and Deno (uses Web Crypto API, no Node-specific dependencies)
- **Provider chain** — resolve credentials via code, environment variables, AppRole, cloud identity (AWS IAM / Azure Managed Identity / GCP), Kubernetes, JWT, or SPIFFE
- **Multi-engine** — KV v1, KV v2, Database, Transit, AWS, Azure, GCP, LDAP, TOTP, plus lease management
- **Built-in caching** — credential and KV secret caches with stampede protection
- **Dual ESM/CJS** — ships both ES module and CommonJS builds

## Install

```bash
npm install @hashicorp/vault-runtime-credential-sdk
```

If using the SPIFFE provider, install the optional peer dependency:

```bash
npm install spiffe@^0.5.0
```

## Runtime Compatibility

This SDK targets **server-side JavaScript runtimes** only. It is not designed for browsers or client-side applications — Vault tokens and cloud identity credentials should never be exposed to end users.

| Runtime | Minimum Version | Notes                   |
| ------- | --------------- | ----------------------- |
| Node.js | >= 18           | Web Crypto API required |
| Bun     | >= 1.0          |                         |
| Deno    | >= 1.35         |                         |

**Module formats**: ESM (primary) + CJS

## Quick Start

```typescript
import { createVaultClient } from '@hashicorp/vault-runtime-credential-sdk';

const client = createVaultClient({
	address: 'https://vault.example.com',
	chain: {
		code: { token: 'hvs.my-dev-token' }
	}
});

// Read a full KV2 secret (data + metadata)
const secret = await client.readKv2({ path: 'myapp/config' });
console.log(secret.data);

// Read a single field
const dbPassword = await client.readKv2Field('myapp/config', 'db_password');
```

## Credential Chain

The SDK resolves Vault credentials by walking an ordered provider chain. The first provider that succeeds wins. If every provider fails, a `CredentialChainExhaustedError` is thrown with details from each provider.

Chain evaluation order: **code → environment → AppRole → cloud identity → Kubernetes → JWT → SPIFFE**

Only the providers present in your `chain` config are evaluated.

```typescript
const client = createVaultClient({
	address: 'https://vault.example.com',
	chain: {
		code: { token: 'hvs.dev-token' },
		environment: { variableName: 'MY_VAULT_TOKEN' },
		appRole: { roleId: 'my-role-id', secretId: 'my-secret-id' },
		cloudIdentity: { provider: 'aws', role: 'my-app-role' },
		kubernetes: { role: 'my-k8s-role' },
		jwt: { role: 'my-jwt-role' },
		spiffe: { role: 'my-spiffe-role' }
	}
});
```

### Code Provider

Supplies a static Vault token directly in configuration. Useful for local development and testing.

```typescript
chain: {
  code: { token: 'hvs.my-token' },
}
```

| Option  | Type     | Required | Description     |
| ------- | -------- | -------- | --------------- |
| `token` | `string` | Yes      | The Vault token |

### Environment Provider

Reads a Vault token from an environment variable.

```typescript
chain: {
  environment: { variableName: 'MY_VAULT_TOKEN' },
}
```

| Option         | Type     | Required | Default         | Description                  |
| -------------- | -------- | -------- | --------------- | ---------------------------- |
| `variableName` | `string` | No       | `'VAULT_TOKEN'` | Environment variable to read |

### AppRole Provider

Authenticates using Vault's AppRole auth method with a `role_id` and `secret_id`. Credentials can be supplied directly or via environment variables.

```typescript
chain: {
  appRole: {
    roleId: 'my-role-id',
    secretId: 'my-secret-id',
    authPath: 'auth/approle/login',
  },
}
```

| Option           | Type     | Required | Default                     | Description                        |
| ---------------- | -------- | -------- | --------------------------- | ---------------------------------- |
| `roleId`         | `string` | No       | —                           | AppRole role ID (or use env var)   |
| `secretId`       | `string` | No       | —                           | AppRole secret ID (or use env var) |
| `roleIdEnvVar`   | `string` | No       | `'VAULT_APPROLE_ROLE_ID'`   | Environment variable for role ID   |
| `secretIdEnvVar` | `string` | No       | `'VAULT_APPROLE_SECRET_ID'` | Environment variable for secret ID |
| `authPath`       | `string` | No       | `'auth/approle/login'`      | Vault auth method mount path       |

### Cloud Identity — AWS IAM

Resolves AWS credentials, signs an `sts:GetCallerIdentity` request with SigV4, and authenticates to Vault's AWS auth method.

AWS credential resolution order:

1. Environment variables (`AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_SESSION_TOKEN`)
2. ECS container credentials (`AWS_CONTAINER_CREDENTIALS_RELATIVE_URI`)
3. EC2 instance profile (IMDS v2)

```typescript
chain: {
  cloudIdentity: {
    provider: 'aws',
    role: 'my-app-role',
    stsRegion: 'us-east-1',
    authPath: 'auth/aws/login',
    iamServerId: 'vault.example.com',
  },
}
```

| Option        | Type     | Required | Default            | Description                         |
| ------------- | -------- | -------- | ------------------ | ----------------------------------- |
| `provider`    | `'aws'`  | Yes      | —                  | Provider type discriminator         |
| `role`        | `string` | Yes      | —                  | Vault role name for AWS auth method |
| `stsRegion`   | `string` | No       | `'us-east-1'`      | AWS region for STS signing          |
| `authPath`    | `string` | No       | `'auth/aws/login'` | Vault auth method mount path        |
| `iamServerId` | `string` | No       | —                  | IAM Server ID header value          |

### Cloud Identity — Azure Managed Identity

Fetches an Azure AD token from the managed identity endpoint and authenticates to Vault's Azure auth method.

Token resolution order:

1. App Service / Functions (`IDENTITY_ENDPOINT` + `IDENTITY_HEADER`)
2. IMDS (VM, VMSS, ACI)

```typescript
chain: {
  cloudIdentity: {
    provider: 'azure',
    role: 'my-app-role',
    resource: 'https://management.azure.com/',
    clientId: 'optional-user-assigned-id',
    authPath: 'auth/azure/login',
  },
}
```

| Option     | Type      | Required | Default                           | Description                          |
| ---------- | --------- | -------- | --------------------------------- | ------------------------------------ |
| `provider` | `'azure'` | Yes      | —                                 | Provider type discriminator          |
| `role`     | `string`  | Yes      | —                                 | Vault role name for Azure auth       |
| `resource` | `string`  | No       | `'https://management.azure.com/'` | Azure resource URI                   |
| `clientId` | `string`  | No       | —                                 | Client ID for user-assigned identity |
| `authPath` | `string`  | No       | `'auth/azure/login'`              | Vault auth method mount path         |

### Cloud Identity — GCP

Authenticates to Vault's GCP auth method. Supports two modes:

- **GCE** (default): Fetches an identity token from the GCE metadata service. Use on Compute Engine, GKE, Cloud Run, or Cloud Functions.
- **IAM**: Accepts a pre-signed JWT that you provide. The SDK does not sign JWTs with GCP service account keys.

```typescript
// GCE mode (auto-fetches identity token from metadata service)
chain: {
  cloudIdentity: {
    provider: 'gcp',
    role: 'my-gcp-role',
  },
}

// IAM mode (provide a pre-signed JWT)
chain: {
  cloudIdentity: {
    provider: 'gcp',
    role: 'my-gcp-role',
    type: 'iam',
    jwt: 'eyJhbGci...',
  },
}
```

| Option                | Type     | Required  | Default            | Description                                      |
| --------------------- | -------- | --------- | ------------------ | ------------------------------------------------ |
| `provider`            | `'gcp'`  | Yes       | —                  | Provider type discriminator                      |
| `role`                | `string` | Yes       | —                  | Vault role name for GCP auth method              |
| `type`                | `string` | No        | `'gce'`            | `'gce'` for metadata, `'iam'` for pre-signed JWT |
| `serviceAccountEmail` | `string` | No        | `'default'`        | GCE service account email (GCE mode only)        |
| `jwt`                 | `string` | Yes (IAM) | —                  | Pre-signed JWT (IAM mode only)                   |
| `authPath`            | `string` | No        | `'auth/gcp/login'` | Vault auth method mount path                     |

### Kubernetes Provider

Reads a Kubernetes service account JWT from the projected token file and authenticates to Vault's Kubernetes auth method.

```typescript
chain: {
  kubernetes: {
    role: 'my-k8s-role',
    tokenPath: '/var/run/secrets/kubernetes.io/serviceaccount/token',
    authPath: 'auth/kubernetes/login',
  },
}
```

| Option      | Type     | Required | Default                                                 | Description                  |
| ----------- | -------- | -------- | ------------------------------------------------------- | ---------------------------- |
| `role`      | `string` | Yes      | —                                                       | Vault role name              |
| `tokenPath` | `string` | No       | `'/var/run/secrets/kubernetes.io/serviceaccount/token'` | Path to service account JWT  |
| `authPath`  | `string` | No       | `'auth/kubernetes/login'`                               | Vault auth method mount path |

### JWT Provider

Authenticates using an externally-provided JWT. The token can be supplied directly or via an environment variable. Role is optional — Vault supports `default_role` configuration.

```typescript
chain: {
  jwt: {
    role: 'my-jwt-role',
    jwt: 'eyJhbGci...',
    authPath: 'auth/jwt/login',
  },
}
```

| Option      | Type     | Required | Default            | Description                  |
| ----------- | -------- | -------- | ------------------ | ---------------------------- |
| `role`      | `string` | No       | —                  | Vault role name (optional)   |
| `jwt`       | `string` | No       | —                  | JWT token (or use env var)   |
| `jwtEnvVar` | `string` | No       | `'VAULT_JWT'`      | Environment variable for JWT |
| `authPath`  | `string` | No       | `'auth/jwt/login'` | Vault auth method mount path |

### SPIFFE Provider

Fetches a JWT SVID from a SPIRE agent and authenticates to Vault's SPIFFE auth method. Requires the `spiffe` peer dependency.

```typescript
chain: {
  spiffe: {
    socketPath: 'unix:///tmp/spire-agent/public/api.sock',
    audience: 'VaultSVIDAuth',
    role: 'my-spiffe-role',
    authPath: 'auth/spiffe/login',
  },
}
```

| Option       | Type     | Required | Default                                     | Description                  |
| ------------ | -------- | -------- | ------------------------------------------- | ---------------------------- |
| `socketPath` | `string` | No       | `'unix:///tmp/spire-agent/public/api.sock'` | SPIRE agent socket path      |
| `audience`   | `string` | No       | `'VaultSVIDAuth'`                           | JWT SVID audience            |
| `role`       | `string` | No       | `'my-role'`                                 | Vault role name              |
| `authPath`   | `string` | No       | `'auth/spiffe/login'`                       | Vault auth method mount path |

## Secret Engines

### KV v2

Reads versioned secrets with metadata. Results are cached using `secretTtlMs`.

```typescript
// Read full secret (data + metadata)
const secret = await client.readKv2({ path: 'myapp/config' });
console.log(secret.data); // { db_password: '...', api_key: '...' }
console.log(secret.metadata.version); // 3

// Read a single field as a string
const password = await client.readKv2Field('myapp/config', 'db_password');

// Custom mount path (default: 'secret')
const secret = await client.readKv2({ path: 'myapp/config', mountPath: 'kv' });
```

### KV v1

Reads unversioned secrets. Results are cached using `secretTtlMs`.

```typescript
// Read full secret
const secret = await client.readKv1({ path: 'myapp/config' });
console.log(secret.data); // { db_password: '...', api_key: '...' }

// Read a single field as a string
const password = await client.readKv1Field('myapp/config', 'db_password');

// Custom mount path (default: 'kv')
const secret = await client.readKv1({ path: 'myapp/config', mountPath: 'legacy-kv' });
```

### Database

Generates dynamic database credentials or reads static ones. Dynamic creds are **never cached** — each call produces fresh credentials with a lease.

```typescript
// Dynamic credentials (new username/password per call)
const creds = await client.getDatabaseCreds({ role: 'readonly' });
console.log(creds.username); // 'v-token-readonly-abc123'
console.log(creds.password); // 'A1a-random-password'
console.log(creds.lease_id); // 'database/creds/readonly/abc123'
console.log(creds.lease_duration); // 3600

// Static credentials (rotated by Vault on a schedule)
const staticCreds = await client.getDatabaseStaticCreds({ role: 'static-admin' });
console.log(staticCreds.username); // 'admin'
console.log(staticCreds.password); // 'rotated-password'
console.log(staticCreds.ttl); // seconds until next rotation

// Custom mount path (default: 'database')
const creds = await client.getDatabaseCreds({ role: 'readonly', mountPath: 'postgres' });
```

### Transit

Encryption, decryption, signing, verification, HMAC, data key generation, and random byte generation. Transit operations are **never cached**.

```typescript
// Encrypt plaintext (base64-encoded input)
const encrypted = await client.transitEncrypt({
	key: 'my-key',
	plaintext: btoa('sensitive data')
});
console.log(encrypted.ciphertext); // 'vault:v1:encrypted-data-here'

// Decrypt ciphertext
const decrypted = await client.transitDecrypt({
	key: 'my-key',
	ciphertext: 'vault:v1:encrypted-data-here'
});
console.log(atob(decrypted.plaintext)); // 'sensitive data'

// Convergent encryption with context
const encrypted = await client.transitEncrypt({
	key: 'my-key',
	plaintext: btoa('data'),
	context: btoa('user-123')
});

// Sign data
const signed = await client.transitSign({
	key: 'my-signing-key',
	input: btoa('data to sign'),
	hashAlgorithm: 'sha2-256'
});
console.log(signed.signature); // 'vault:v1:signature...'

// Verify signature
const verified = await client.transitVerify({
	key: 'my-signing-key',
	input: btoa('data to sign'),
	signature: signed.signature,
	hashAlgorithm: 'sha2-256'
});
console.log(verified.valid); // true

// Generate HMAC
const hmac = await client.transitHmac({
	key: 'my-key',
	input: btoa('data'),
	algorithm: 'sha2-512'
});
console.log(hmac.hmac); // 'vault:v1:hmac...'

// Generate a data encryption key
const datakey = await client.transitDatakey({
	key: 'my-key',
	type: 'plaintext', // or 'wrapped' for ciphertext-only
	bits: 256
});
console.log(datakey.plaintext); // base64-encoded key (only with type: 'plaintext')
console.log(datakey.ciphertext); // wrapped key for storage

// Generate random bytes
const random = await client.transitRandom({ bytes: 32, format: 'hex' });
console.log(random.random_bytes); // hex-encoded random data

// Custom mount path (default: 'transit')
const encrypted = await client.transitEncrypt({
	key: 'my-key',
	plaintext: btoa('data'),
	mountPath: 'encryption'
});
```

### AWS Dynamic Secrets

Generates dynamic AWS IAM credentials or STS tokens. **Never cached**.

```typescript
// IAM credentials (long-lived, lease-managed)
const creds = await client.getAwsCreds({ role: 'my-role' });
console.log(creds.access_key); // 'AKIAIOSFODNN7EXAMPLE'
console.log(creds.secret_key); // 'wJalrXUtnFEMI...'
console.log(creds.security_token); // present for assumed roles
console.log(creds.lease_id); // for lease renewal/revocation

// STS credentials (short-lived, federation tokens)
const stsCreds = await client.getAwsStsCreds({
	role: 'my-role',
	ttl: '1h',
	roleArn: 'arn:aws:iam::123456789012:role/cross-account'
});
console.log(stsCreds.access_key);
console.log(stsCreds.secret_key);
console.log(stsCreds.security_token);

// Custom mount path (default: 'aws')
const creds = await client.getAwsCreds({ role: 'my-role', mountPath: 'aws-prod' });
```

### Azure Dynamic Secrets

Generates dynamic Azure service principal credentials. **Never cached**.

```typescript
const creds = await client.getAzureCreds({ role: 'my-role' });
console.log(creds.client_id); // Azure AD application client ID
console.log(creds.client_secret); // Generated client secret
console.log(creds.lease_id); // for lease renewal/revocation
console.log(creds.lease_duration); // seconds

// Custom mount path (default: 'azure')
const creds = await client.getAzureCreds({ role: 'my-role', mountPath: 'azure-prod' });
```

### GCP Dynamic Secrets

Generates OAuth2 access tokens or service account keys. **Never cached**.

```typescript
// OAuth2 access token (from a roleset)
const token = await client.getGcpToken({ roleset: 'my-roleset' });
console.log(token.token); // 'ya29.c.example-access-token'
console.log(token.expires_at_seconds); // Unix timestamp
console.log(token.token_ttl); // seconds

// OAuth2 access token (from a static account)
const token = await client.getGcpToken({ staticAccount: 'my-account' });

// Service account key (from a roleset)
const key = await client.getGcpKey({ roleset: 'my-roleset' });
console.log(key.private_key_data); // base64-encoded JSON key file
console.log(key.key_algorithm); // 'KEY_ALG_RSA_2048'
console.log(key.key_type); // 'TYPE_GOOGLE_CREDENTIALS_FILE'
console.log(key.lease_id); // for lease renewal/revocation

// Custom mount path (default: 'gcp')
const token = await client.getGcpToken({ roleset: 'my-roleset', mountPath: 'gcp-prod' });
```

> **Note:** Specify exactly one of `roleset` or `staticAccount` — providing both or neither throws an error.

### LDAP

Generates dynamic LDAP credentials, reads static credentials, and manages service account library checkout/checkin. Dynamic creds are **never cached**.

```typescript
// Dynamic credentials
const creds = await client.getLdapCreds({ role: 'my-role' });
console.log(creds.username); // 'v-token-my-role-abc123'
console.log(creds.password); // generated password
console.log(creds.distinguished_names); // optional DN array
console.log(creds.lease_id); // for lease renewal/revocation

// Static credentials (rotated by Vault)
const staticCreds = await client.getLdapStaticCreds({ role: 'static-role' });
console.log(staticCreds.username);
console.log(staticCreds.password);
console.log(staticCreds.dn); // distinguished name
console.log(staticCreds.ttl); // seconds until next rotation

// Check out a service account from a library set
const checkout = await client.checkoutLdapAccount({ set: 'my-set', ttl: '1h' });
console.log(checkout.service_account_names); // ['svc@example.com']
console.log(checkout.lease_id);

// Check in a service account
await client.checkinLdapAccount({
	set: 'my-set',
	serviceAccountNames: ['svc@example.com']
});

// Custom mount path (default: 'ldap')
const creds = await client.getLdapCreds({ role: 'my-role', mountPath: 'openldap' });
```

### TOTP

Generates and validates time-based one-time passwords. **Never cached** — each call produces fresh codes.

```typescript
// Generate a TOTP code
const result = await client.getTotpCode({ name: 'my-key' });
console.log(result.code); // '123456'

// Validate a TOTP code
const validation = await client.validateTotpCode({ name: 'my-key', code: '123456' });
console.log(validation.valid); // true or false

// Custom mount path (default: 'totp')
const result = await client.getTotpCode({ name: 'my-key', mountPath: 'custom-totp' });
```

### Lease Management

Renew or revoke leases returned by dynamic credential engines (Database, AWS, Azure, GCP, LDAP).

```typescript
// Renew a lease
const dbCreds = await client.getDatabaseCreds({ role: 'readonly' });
const renewed = await client.renewLease({ leaseId: dbCreds.lease_id, increment: 7200 });
console.log(renewed.lease_duration); // new TTL in seconds

// Revoke a lease
await client.revokeLease({ leaseId: dbCreds.lease_id });
```

## Caching

The SDK caches credentials and KV (v1 and v2) secrets to reduce Vault traffic. Dynamic credentials, Transit operations, and TOTP are **never cached** — each call goes directly to Vault.

| Cache      | Default TTL | Cache Key        | Engines              |
| ---------- | ----------- | ---------------- | -------------------- |
| Credential | 5 minutes   | `credential`     | All (authentication) |
| KV2 Secret | 60 seconds  | `{mount}:{path}` | KV v2                |
| KV1 Secret | 60 seconds  | `{mount}:{path}` | KV v1                |

**Not cached:** Database, Transit, AWS, Azure, GCP, LDAP, TOTP, Lease operations.

### Stampede Protection

Concurrent calls to `resolveCredential()` while a credential request is already in flight will share the same promise rather than issuing duplicate Vault requests.

### Configuration

```typescript
const client = createVaultClient({
	address: 'https://vault.example.com',
	chain: { environment: {} },
	cache: {
		credentialTtlMs: 600_000, // 10 minutes
		secretTtlMs: 30_000 // 30 seconds (applies to KV1 + KV2)
	}
});
```

Set a TTL to `0` to disable that cache.

### Manual Invalidation

```typescript
client.clearCache(); // clears credential, KV1, and KV2 caches
```

## Error Handling

### `VaultSdkError`

Thrown when a Vault API request returns a non-success status.

```typescript
import { VaultSdkError } from '@hashicorp/vault-runtime-credential-sdk';

try {
	await client.readKv2({ path: 'missing/secret' });
} catch (err) {
	if (err instanceof VaultSdkError) {
		console.error(err.status); // HTTP status code
		console.error(err.body); // Response body
		console.error(err.endpoint); // Vault endpoint
	}
}
```

### `CredentialChainExhaustedError`

Thrown when every provider in the chain fails.

```typescript
import { CredentialChainExhaustedError } from '@hashicorp/vault-runtime-credential-sdk';

try {
	await client.resolveCredential();
} catch (err) {
	if (err instanceof CredentialChainExhaustedError) {
		for (const { provider, message } of err.providerErrors) {
			console.error(`${provider}: ${message}`);
		}
	}
}
```

## API Reference

### `createVaultClient(config: VaultClientConfig): VaultClient`

Factory function that returns a configured `VaultClient`.

### `VaultClient`

#### KV v1 / v2

| Method         | Signature                                                              | Description                        |
| -------------- | ---------------------------------------------------------------------- | ---------------------------------- |
| `readKv2`      | `(params: Kv2ReadParams) => Promise<Kv2SecretData>`                    | Read full KV2 secret with metadata |
| `readKv2Field` | `(path: string, field: string, mountPath?: string) => Promise<string>` | Read a single KV2 field as string  |
| `readKv1`      | `(params: Kv1ReadParams) => Promise<Kv1SecretData>`                    | Read full KV1 secret               |
| `readKv1Field` | `(path: string, field: string, mountPath?: string) => Promise<string>` | Read a single KV1 field as string  |

#### Database

| Method                   | Signature                                                        | Description               |
| ------------------------ | ---------------------------------------------------------------- | ------------------------- |
| `getDatabaseCreds`       | `(params: DatabaseCredsParams) => Promise<DatabaseDynamicCreds>` | Generate dynamic DB creds |
| `getDatabaseStaticCreds` | `(params: DatabaseCredsParams) => Promise<DatabaseStaticCreds>`  | Read static DB creds      |

#### Transit

| Method           | Signature                                                         | Description           |
| ---------------- | ----------------------------------------------------------------- | --------------------- |
| `transitEncrypt` | `(params: TransitEncryptParams) => Promise<TransitEncryptResult>` | Encrypt data          |
| `transitDecrypt` | `(params: TransitDecryptParams) => Promise<TransitDecryptResult>` | Decrypt data          |
| `transitSign`    | `(params: TransitSignParams) => Promise<TransitSignResult>`       | Sign data             |
| `transitVerify`  | `(params: TransitVerifyParams) => Promise<TransitVerifyResult>`   | Verify signature      |
| `transitHmac`    | `(params: TransitHmacParams) => Promise<TransitHmacResult>`       | Generate HMAC         |
| `transitDatakey` | `(params: TransitDatakeyParams) => Promise<TransitDatakeyResult>` | Generate data key     |
| `transitRandom`  | `(params?: TransitRandomParams) => Promise<TransitRandomResult>`  | Generate random bytes |

#### Cloud Dynamic Secrets

| Method           | Signature                                                  | Description             |
| ---------------- | ---------------------------------------------------------- | ----------------------- |
| `getAwsCreds`    | `(params: AwsCredsParams) => Promise<AwsDynamicCreds>`     | AWS IAM credentials     |
| `getAwsStsCreds` | `(params: AwsStsCredsParams) => Promise<AwsDynamicCreds>`  | AWS STS credentials     |
| `getAzureCreds`  | `(params: AzureCredsParams) => Promise<AzureDynamicCreds>` | Azure SP credentials    |
| `getGcpToken`    | `(params: GcpTokenParams) => Promise<GcpTokenResult>`      | GCP OAuth2 access token |
| `getGcpKey`      | `(params: GcpKeyParams) => Promise<GcpKeyResult>`          | GCP service account key |

#### LDAP

| Method                | Signature                                                     | Description                 |
| --------------------- | ------------------------------------------------------------- | --------------------------- |
| `getLdapCreds`        | `(params: LdapCredsParams) => Promise<LdapDynamicCreds>`      | Generate dynamic LDAP creds |
| `getLdapStaticCreds`  | `(params: LdapCredsParams) => Promise<LdapStaticCreds>`       | Read static LDAP creds      |
| `checkoutLdapAccount` | `(params: LdapCheckoutParams) => Promise<LdapCheckoutResult>` | Check out service account   |
| `checkinLdapAccount`  | `(params: LdapCheckinParams) => Promise<void>`                | Check in service account    |

#### TOTP

| Method             | Signature                                                     | Description        |
| ------------------ | ------------------------------------------------------------- | ------------------ |
| `getTotpCode`      | `(params: TotpCodeParams) => Promise<TotpCodeResult>`         | Generate TOTP code |
| `validateTotpCode` | `(params: TotpValidateParams) => Promise<TotpValidateResult>` | Validate TOTP code |

#### Lease Management

| Method        | Signature                                           | Description    |
| ------------- | --------------------------------------------------- | -------------- |
| `renewLease`  | `(params: LeaseRenewParams) => Promise<VaultLease>` | Renew a lease  |
| `revokeLease` | `(params: LeaseRevokeParams) => Promise<void>`      | Revoke a lease |

#### Credential / Cache

| Method              | Signature                        | Description                           |
| ------------------- | -------------------------------- | ------------------------------------- |
| `resolveCredential` | `() => Promise<VaultCredential>` | Resolve a credential from the chain   |
| `clearCache`        | `() => void`                     | Clear credential and KV secret caches |

## Development

```bash
npm run build          # ESM + CJS bundles via tsup
npm run test           # 332 tests via vitest
npm run test:coverage  # Tests with coverage report
npm run check          # TypeScript type checking
npm run lint           # Prettier + ESLint
npm run format         # Auto-format with Prettier
npm run dist           # Build versioned release archive (.tar.gz)
npm run test:runtimes  # Runtime smoke tests (Node.js, Bun, Deno)
```

## Project Structure

```
src/
├── index.ts                       # Public API exports
├── types.ts                       # All interfaces and type definitions
├── client.ts                      # createVaultClient factory
├── chain.ts                       # Credential chain resolver
├── vault-fetch.ts                 # Shared HTTP helper (vaultFetch, vaultFetchLeased)
├── kv2.ts                         # KV v2 read operations
├── kv1.ts                         # KV v1 read operations
├── database.ts                    # Database dynamic + static credentials
├── transit.ts                     # Transit encrypt/decrypt/sign/verify/hmac/datakey/random
├── aws-secrets.ts                 # AWS IAM + STS dynamic credentials
├── azure-secrets.ts               # Azure dynamic credentials
├── gcp-secrets.ts                 # GCP OAuth token + service account key
├── ldap.ts                        # LDAP creds/static-creds/checkout/checkin
├── totp.ts                        # TOTP code generation + validation
├── lease.ts                       # Lease renew + revoke
├── cache.ts                       # TTL cache with lazy eviction
├── errors.ts                      # VaultSdkError, CredentialChainExhaustedError
├── runtime-fs.ts                  # Runtime-adaptive file reader (Node/Bun/Deno)
└── providers/
    ├── index.ts                   # Provider barrel exports
    ├── code.ts                    # Static token provider
    ├── environment.ts             # Environment variable provider
    ├── approle.ts                 # AppRole auth
    ├── cloud-identity.ts          # Cloud identity dispatcher
    ├── aws-iam.ts                 # AWS IAM SigV4 auth
    ├── azure-managed-identity.ts  # Azure Managed Identity auth
    ├── gcp.ts                     # GCP (GCE + IAM) auth
    ├── kubernetes.ts              # Kubernetes service account auth
    ├── jwt.ts                     # JWT auth
    └── spiffe.ts                  # SPIFFE JWT SVID auth
```

## License

[MIT](./LICENSE)
